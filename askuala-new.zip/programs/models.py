from django.db import models


class Program(models.Model):
    programId = models.AutoField(primary_key=True)
    programName = models.CharField(max_length=63)
    programDescription = models.CharField(max_length=63, null=True)
    programInfoLink = models.CharField(max_length=255, null=True)

    def __str__(self):
        return self.programName


class Department(models.Model):
    departmentId = models.AutoField(primary_key=True)
    departmentName = models.CharField(max_length=127)
    departmentDescription = models.CharField(max_length=1023, null=True)
    program = models.ManyToManyField(Program)
    departmentHead = models.CharField(max_length=127, null=True)

    def __str__(self):
        return self.departmentName


class Courses(models.Model):
    courseId = models.AutoField(primary_key=True)
    courseName = models.CharField(max_length=255)
    courseDescription = models.CharField(max_length=1023, null=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    semester = models.PositiveSmallIntegerField(choices=[(1,1), (2,2)])

    def __str__(self):
        return self.courseName
